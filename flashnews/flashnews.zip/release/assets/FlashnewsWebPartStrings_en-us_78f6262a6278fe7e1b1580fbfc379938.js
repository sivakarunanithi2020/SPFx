define([], function() {
  return {
    "PropertyPaneDescription": "Flash News",
    "BasicGroupName": "WebPart Configuration",
    "DescriptionFieldLabel": "Description Field"
  }
});