/* tslint:disable */
require("./Flashnews.module.css");
const styles = {
  flashnews: 'flashnews_6e4aafc0',
  containerhide: 'containerhide_6e4aafc0',
  container: 'container_6e4aafc0',
  row: 'row_6e4aafc0',
  column: 'column_6e4aafc0',
  'ms-Grid': 'ms-Grid_6e4aafc0',
  title: 'title_6e4aafc0',
  subTitle: 'subTitle_6e4aafc0',
  description: 'description_6e4aafc0',
  button: 'button_6e4aafc0',
  label: 'label_6e4aafc0'
};

export default styles;
/* tslint:enable */