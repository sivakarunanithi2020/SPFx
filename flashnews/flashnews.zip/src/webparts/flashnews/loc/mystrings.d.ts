declare interface IFlashnewsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'FlashnewsWebPartStrings' {
  const strings: IFlashnewsWebPartStrings;
  export = strings;
}
